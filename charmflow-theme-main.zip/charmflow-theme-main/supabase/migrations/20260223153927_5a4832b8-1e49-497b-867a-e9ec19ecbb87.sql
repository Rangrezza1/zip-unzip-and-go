
-- Create storage bucket for hero banner images
INSERT INTO storage.buckets (id, name, public) VALUES ('hero-banners', 'hero-banners', true)
ON CONFLICT (id) DO NOTHING;

-- Allow anyone to view hero banner images
CREATE POLICY "Hero banners are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'hero-banners');

-- Allow anyone to upload hero banners (admin-only enforced at app level)
CREATE POLICY "Anyone can upload hero banners"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'hero-banners');

-- Allow anyone to delete hero banners
CREATE POLICY "Anyone can delete hero banners"
ON storage.objects FOR DELETE
USING (bucket_id = 'hero-banners');
