import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export interface SectionSettings {
  id: string;
  type: string;
  enabled: boolean;
  backgroundColor: string;
  backgroundImage: string;
  paddingTop: number;
  paddingBottom: number;
  marginTop: number;
  marginBottom: number;
  textAlign: 'left' | 'center' | 'right';
  animationEnabled: boolean;
  decorativeStyle: 'none' | 'divider' | 'dots' | 'wave';
  settings: Record<string, unknown>;
}

export interface CollectionSectionSettings {
  collectionQuery: string;
  headline: string;
  subheading: string;
  headingStyle: 'none' | 'underline' | 'accent-bar' | 'icon' | 'divider';
  ctaText: string;
  ctaLink: string;
  productLimit: number;
  gridColumns: 2 | 3 | 4;
  hoverImage: boolean;
  quickAdd: boolean;
  saleBadge: boolean;
  tagBadges: boolean;
  shadowEffect: boolean;
  animationEnabled: boolean;
}

export interface FeaturedCollectionSection {
  id: string;
  collectionHandle: string;
  enabled: boolean;
  headline: string;
  subheading: string;
  headingStyle: 'none' | 'underline' | 'accent-bar' | 'icon' | 'divider';
  ctaText: string;
  productLimit: number;
  gridColumns: 2 | 3 | 4;
  shadowEffect: boolean;
  animationEnabled: boolean;
}

export interface HeroBanner {
  id: string;
  imageUrl: string;
  title: string;
  subtitle: string;
  ctaText: string;
  ctaLink: string;
}

export interface ThemeSettings {
  heroBanners: HeroBanner[];
  heroAutoRotate: boolean;
  heroRotateInterval: number;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  gradientEnabled: boolean;
  gradientFrom: string;
  gradientTo: string;
  fontFamily: string;
  headingFontWeight: string;
  buttonStyle: 'rounded' | 'square';
  borderRadius: number;
  sectionSpacing: number;
  containerWidth: number;
  saleBadgeColor: string;
  tagBadgeColor: string;
  animationsEnabled: boolean;
  stickyHeader: boolean;
  stickyAddToCart: boolean;
  freeShippingThreshold: number;
  lowStockThreshold: number;
  sections: SectionSettings[];
  collectionSections: CollectionSectionSettings[];
  featuredCollections: FeaturedCollectionSection[];
}

const defaultSections: SectionSettings[] = [
  { id: 'hero', type: 'hero', enabled: true, backgroundColor: '', backgroundImage: '', paddingTop: 0, paddingBottom: 0, marginTop: 0, marginBottom: 0, textAlign: 'center', animationEnabled: true, decorativeStyle: 'none', settings: {} },
  { id: 'categories', type: 'categories', enabled: true, backgroundColor: '', backgroundImage: '', paddingTop: 24, paddingBottom: 24, marginTop: 0, marginBottom: 0, textAlign: 'center', animationEnabled: true, decorativeStyle: 'none', settings: {} },
  { id: 'products', type: 'products', enabled: true, backgroundColor: '', backgroundImage: '', paddingTop: 24, paddingBottom: 24, marginTop: 0, marginBottom: 0, textAlign: 'left', animationEnabled: true, decorativeStyle: 'none', settings: {} },
  { id: 'promo', type: 'promo', enabled: true, backgroundColor: '', backgroundImage: '', paddingTop: 0, paddingBottom: 0, marginTop: 0, marginBottom: 0, textAlign: 'center', animationEnabled: true, decorativeStyle: 'none', settings: {} },
];

const defaultTheme: ThemeSettings = {
  heroBanners: [
    { id: 'default-1', imageUrl: '', title: 'Upto 50% OFF', subtitle: 'Premium Lawn & Dhanak collections. Shop Now Before It\'s Gone!', ctaText: 'Shop Now', ctaLink: '/collections' },
  ],
  heroAutoRotate: true,
  heroRotateInterval: 5,
  primaryColor: '38 65% 50%',
  secondaryColor: '35 15% 90%',
  accentColor: '38 65% 50%',
  gradientEnabled: false,
  gradientFrom: '38 65% 50%',
  gradientTo: '36 70% 38%',
  fontFamily: 'DM Sans',
  headingFontWeight: '600',
  buttonStyle: 'square',
  borderRadius: 4,
  sectionSpacing: 40,
  containerWidth: 1400,
  saleBadgeColor: '0 72% 51%',
  tagBadgeColor: '38 65% 50%',
  animationsEnabled: true,
  stickyHeader: true,
  stickyAddToCart: true,
  freeShippingThreshold: 3000,
  lowStockThreshold: 5,
  sections: defaultSections,
  collectionSections: [],
  featuredCollections: [],
};

interface ThemeStore {
  theme: ThemeSettings;
  updateTheme: (partial: Partial<ThemeSettings>) => void;
  updateSection: (id: string, partial: Partial<SectionSettings>) => void;
  addSection: (section: SectionSettings) => void;
  removeSection: (id: string) => void;
  reorderSections: (sections: SectionSettings[]) => void;
  duplicateSection: (id: string) => void;
  addCollectionSection: () => void;
  updateCollectionSection: (index: number, partial: Partial<CollectionSectionSettings>) => void;
  removeCollectionSection: (index: number) => void;
  addHeroBanner: () => void;
  updateHeroBanner: (id: string, partial: Partial<HeroBanner>) => void;
  removeHeroBanner: (id: string) => void;
  addFeaturedCollection: (handle: string, title: string) => void;
  updateFeaturedCollection: (id: string, partial: Partial<FeaturedCollectionSection>) => void;
  removeFeaturedCollection: (id: string) => void;
  reorderFeaturedCollections: (collections: FeaturedCollectionSection[]) => void;
  syncFeaturedCollections: (shopifyCollections: { handle: string; title: string }[]) => void;
  resetTheme: () => void;
}

export const useThemeStore = create<ThemeStore>()(
  persist(
    (set, get) => ({
      theme: defaultTheme,

      updateTheme: (partial) =>
        set({ theme: { ...get().theme, ...partial } }),

      updateSection: (id, partial) =>
        set({ theme: { ...get().theme, sections: get().theme.sections.map((s) => s.id === id ? { ...s, ...partial } : s) } }),

      addSection: (section) =>
        set({ theme: { ...get().theme, sections: [...get().theme.sections, section] } }),

      removeSection: (id) =>
        set({ theme: { ...get().theme, sections: get().theme.sections.filter((s) => s.id !== id) } }),

      reorderSections: (sections) =>
        set({ theme: { ...get().theme, sections } }),

      duplicateSection: (id) => {
        const section = get().theme.sections.find((s) => s.id === id);
        if (!section) return;
        const newSection = { ...section, id: `${section.id}-${Date.now()}` };
        const idx = get().theme.sections.findIndex((s) => s.id === id);
        const sections = [...get().theme.sections];
        sections.splice(idx + 1, 0, newSection);
        set({ theme: { ...get().theme, sections } });
      },

      addCollectionSection: () =>
        set({ theme: { ...get().theme, collectionSections: [...get().theme.collectionSections, { collectionQuery: '', headline: `Collection ${get().theme.collectionSections.length + 1}`, subheading: 'Handpicked for you', headingStyle: 'accent-bar', ctaText: 'View All', ctaLink: '/collections', productLimit: 8, gridColumns: 4, hoverImage: true, quickAdd: true, saleBadge: true, tagBadges: true, shadowEffect: false, animationEnabled: true }] } }),

      updateCollectionSection: (index, partial) =>
        set({ theme: { ...get().theme, collectionSections: get().theme.collectionSections.map((s, i) => i === index ? { ...s, ...partial } : s) } }),

      removeCollectionSection: (index) =>
        set({ theme: { ...get().theme, collectionSections: get().theme.collectionSections.filter((_, i) => i !== index) } }),

      addHeroBanner: () =>
        set({ theme: { ...get().theme, heroBanners: [...get().theme.heroBanners, { id: `banner-${Date.now()}`, imageUrl: '', title: 'New Banner', subtitle: 'Edit this banner', ctaText: 'Shop Now', ctaLink: '/collections' }] } }),

      updateHeroBanner: (id, partial) =>
        set({ theme: { ...get().theme, heroBanners: get().theme.heroBanners.map((b) => b.id === id ? { ...b, ...partial } : b) } }),

      removeHeroBanner: (id) =>
        set({ theme: { ...get().theme, heroBanners: get().theme.heroBanners.filter((b) => b.id !== id) } }),

      addFeaturedCollection: (handle, title) =>
        set({ theme: { ...get().theme, featuredCollections: [...get().theme.featuredCollections, {
          id: `fc-${handle}-${Date.now()}`,
          collectionHandle: handle,
          enabled: true,
          headline: title,
          subheading: '',
          headingStyle: 'accent-bar',
          ctaText: 'View All',
          productLimit: 8,
          gridColumns: 4,
          shadowEffect: false,
          animationEnabled: true,
        }] } }),

      updateFeaturedCollection: (id, partial) =>
        set({ theme: { ...get().theme, featuredCollections: get().theme.featuredCollections.map((fc) => fc.id === id ? { ...fc, ...partial } : fc) } }),

      removeFeaturedCollection: (id) =>
        set({ theme: { ...get().theme, featuredCollections: get().theme.featuredCollections.filter((fc) => fc.id !== id) } }),

      reorderFeaturedCollections: (collections) =>
        set({ theme: { ...get().theme, featuredCollections: collections } }),

      syncFeaturedCollections: (shopifyCollections) => {
        const existing = get().theme.featuredCollections;
        const existingHandles = new Set(existing.map(fc => fc.collectionHandle));
        const newCollections = shopifyCollections
          .filter(c => !existingHandles.has(c.handle))
          .map(c => ({
            id: `fc-${c.handle}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            collectionHandle: c.handle,
            enabled: true,
            headline: c.title,
            subheading: '',
            headingStyle: 'accent-bar' as const,
            ctaText: 'View All',
            productLimit: 8,
            gridColumns: 4 as const,
            shadowEffect: false,
            animationEnabled: true,
          }));
        if (newCollections.length > 0) {
          set({ theme: { ...get().theme, featuredCollections: [...existing, ...newCollections] } });
        }
      },

      resetTheme: () => set({ theme: defaultTheme }),
    }),
    { name: 'theme-settings', storage: createJSONStorage(() => localStorage) }
  )
);
